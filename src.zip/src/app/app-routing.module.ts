import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChatboxComponent } from './chatbox/chatbox.component';
import { LoginpageComponent } from './loginpage/loginpage.component';


const routes: Routes = [
   { path: '',component: LoginpageComponent},
   { path :'chatbox' , component: ChatboxComponent},
   {path :'loginpage', component: LoginpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [ChatboxComponent ,LoginpageComponent]
