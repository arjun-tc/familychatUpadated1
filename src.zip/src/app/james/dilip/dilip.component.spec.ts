import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DilipComponent } from './dilip.component';

describe('DilipComponent', () => {
  let component: DilipComponent;
  let fixture: ComponentFixture<DilipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DilipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DilipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
