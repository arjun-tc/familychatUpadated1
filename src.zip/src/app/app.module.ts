import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ FormsModule} from '@angular/forms';

import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { JamesComponent } from './james/james.component';
import { AdithyaComponent } from './james/adithya/adithya.component';
import { DilipComponent } from './james/dilip/dilip.component';
import { StephenComponent } from './james/stephen/stephen.component';
import { GrootComponent } from './james/adithya/groot/groot.component';
import { ThorComponent } from './james/dilip/thor/thor.component';
import { PersonComponent } from './person/person.component';
import { GroupmessageComponent } from './groupmessage/groupmessage.component';
// import { ChatboxComponent } from './chatbox/chatbox.component';
// import { LoginpageComponent } from './loginpage/loginpage.component';

@NgModule({
  declarations: [
    AppComponent,
    JamesComponent,
    AdithyaComponent,
    DilipComponent,
    StephenComponent,
    GrootComponent,
    ThorComponent,
    PersonComponent,
    routingComponents,
    GroupmessageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
