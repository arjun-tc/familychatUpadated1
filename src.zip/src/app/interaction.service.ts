import { Injectable } from '@angular/core';
import { Subject, config } from 'rxjs';
@Injectable({
   providedIn: 'root'
})
export class InteractionService {
   private _MessageSource = new Subject<string>();
   private _senderNameSource = new Subject<string>();
   private _receiverNameSource = new Subject<string>();
   private _replyMessageSource = new Subject<string>();
   replyMessage$ = this._replyMessageSource.asObservable();
   Message$ = this._MessageSource.asObservable();
   senderName$ = this._senderNameSource.asObservable();
   receiverName$ = this._receiverNameSource.asObservable();
   receiver: string;
   sender: string;
   message: string;
   reply = "xyz12";
   check = false;
   chat = [];

   people = [{
      "name": "James", "Ques": { "what is your Name": "James", "How Old are you": 89 }, "About": "ParentData"
   },
   {
      "name": "Adithya", "Ques": { "what is your Name": "Adithya", "How Old are you": 45 }, "About": "Child1Data"
   },
   {
      "name": "Dilip", "Ques": { "what is your Name": "Dilip", "How Old are you": 43 }, "About": "Child2Data"
   },
   {
      "name": "Stephen", "Ques": { "what is your Name": "Stephen", "How Old are you": 35 }, "About": "Child3Data"
   },
   {
      "name": "Groot", "Ques": { "what is your Name": "Groot", "How Old are you": 23 }, "About": "SonOfAdithya"
   },
   {
      "name": "Thor", "Ques": { "what is your Name": "Thor", "How Old are you": 20 }, "About": "SonOfDilip"
   }
   ];
   names = { "parentName": "James", "child1Name": "Adithya", "child2Name": "Dilip", "child3Name": "Stephen", "SonOfAdithya": "Groot", "SonOfDilip": "Thor" }
   constructor() { }
   sendMessage(receiverName: string, message: string, senderName: string) {
      this._MessageSource.next(message);
      this._senderNameSource.next(senderName);
      this._receiverNameSource.next(receiverName);
      this.receiver = receiverName;
      this.sender = senderName;
      this.message = message;
      // this.chat.push(`${this.sender} : ${this.message}`); 
      if (this.check) {
         this.chat.splice(this.chat.length - 1, 0, `${this.sender} : @${this.receiver} ${this.message}`);
      }

   }
   sendReply(reply: string) {
      this._replyMessageSource.next(reply);
      this.check = (this.reply != reply && reply != "xyz12") ? true : false;
      this.reply = reply;
      if (this.check){
         //   this.chat.push(` ${reply}`);
         this.chat.splice(this.chat.length, 0, ` ${reply}`);}

   }
}




